
public class MyMain
{

	public static void main(String[] args)
	{
		System.out.println("Hello");

	}

}
