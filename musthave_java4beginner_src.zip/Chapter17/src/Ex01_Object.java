public class Ex01_Object extends Object
{
    String name;
    String getName()
    {
        return name;
    }
}
