public class Ex08_parseXXX
{
    public static void main(String[] args)
    {
        String str = "100";
        int a = Integer.parseInt(str);
        double b = Double.parseDouble("3.14");
        
        System.out.println(a + " : " + b);
    }
}
