public class Ex02_toString1
{
    public static void main(String[] args)
    {
        String name = "홍길동";
        System.out.println(name);
        System.out.println(name.toString());
    }
}
