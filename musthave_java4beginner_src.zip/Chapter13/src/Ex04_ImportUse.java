import com.study.Banana;

public class Ex04_ImportUse
{
    public static void main(String[] args)
    {
        Banana banana = new Banana();
        banana.showName();
    }
}
