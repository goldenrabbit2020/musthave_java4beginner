package com.study;

public class Banana
{
    public void showName() 
    {
        System.out.println("My name is banana.");
    }
}
