public class Apple
{
    public void showName() 
    {
        System.out.println("My name is apple.");
    }
}
