public class Ex01_StringUse
{
    public static void main(String[] args)
    {
        String str1 = new String("자바프로그래밍");
        String str2 = new String("자바프로그래밍");
        String str3 = "자바프로그래밍";
        String str4 = "자바프로그래밍"; 

        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);
        System.out.println(str4);

        // 문자열은 문자와 달리 내용 없이 다음과 같이 사용할 수 있습니다.
        String str5 = ""; 
    }
}
