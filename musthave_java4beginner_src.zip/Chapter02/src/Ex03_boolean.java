public class Ex03_boolean
{
    public static void main(String[] args)
    {
        boolean check1 = true;      // 직접 값 대입
        boolean check2 = false;
        boolean check3 = (1 < 2);   // 연산의 결과를 값으로 대입
        
        System.out.println(check1);
        System.out.println(check2);
        System.out.println(check3);
        System.out.println(1 > 2);  // 연산의 결과를 출력
    }
}
