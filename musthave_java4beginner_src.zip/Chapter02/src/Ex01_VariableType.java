public class Ex01_VariableType
{
	public static void main(String[] args)
	{
		byte num1 = 1;
		short num2 = 1;
		int num3 = 1;
		long num4 = 1;
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
	}
}
